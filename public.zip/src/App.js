import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Components/Navbar/Navbar';
import Footer from './Components/Footer/Footer';
import Home from './Pages/Home';
import CakeCategories from './Pages/CakeCategories';
import CakeDetails from './Pages/CakeDetails';
import CartPage from './Components/Cart/CartPage';
import AboutUs from './Pages/AboutUs';


function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/categories" element={<CakeCategories />} />
        <Route path="/categories/:cakeId" element={<CakeDetails />} />
        <Route path="/Components/Cart/CartPage.js" element={<CartPage />} />
        <Route path="/Pages/AboutUs.js" element={<AboutUs />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
