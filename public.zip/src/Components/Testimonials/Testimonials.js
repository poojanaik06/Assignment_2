import React from 'react';
import './Testimonials.css';

function Testimonials() {
  return (
    <section className="testimonials">
      <h2>From the Caake Delights!</h2>
      <div className="testimonial">
        <p>“My order that got delivered today...Thank you!!” - Leena Barman</p>
      </div>
      <div className="testimonial">
        <p>“The Banana Biscoff Tres Leches...delicious.” - Sohini Shah</p>
      </div>
    </section>
  );
}

export default Testimonials;
