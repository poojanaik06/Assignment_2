import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css'; // Styling for the Navbar component

function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <h1><Link to="/">Cake Delight</Link></h1>
      </div>
      <ul className="navbar-links">
        <li><Link to="./">Home</Link></li>
        <li>
          <Link to="#mini-cakes">Categories</Link>
        </li>
        <li><Link to="./Pages/AboutUs.js">About</Link></li>
        <li><Link to="#contact">Contact Us</Link></li>
        <li><Link to="./Components/Cart/CartPage.js">Cart</Link></li>
      </ul>
      <div className="navbar-icons">
        <Link to="/profile"><i className="fa fa-user"></i></Link>
        <Link to="/search"><i className="fa fa-search"></i></Link>
        <Link to="/cart"><i className="fa fa-shopping-cart"></i></Link>
      </div>
    </nav>
  );
}

export default Navbar;
