import React from 'react';
import './FeaturedSections.css';

function FeaturedSections() {
  return (
    <section className="featured-sections">
      <div className="feature">
        <h2>Scrumptious Cakes to Make Your Day More Special</h2>
        <p>At Cake Delight, we handcraft the best-flavored cakes and bakes...</p>
        <button>Read More</button>
      </div>
      <div className="highlights">
        <div>Delivered in 2 hours</div>
        <div>Made for luxury</div>
        <div>Hand-crafted</div>
        <div>No artificial flavouring</div>
      </div>
    </section>
  );
}

export default FeaturedSections;
