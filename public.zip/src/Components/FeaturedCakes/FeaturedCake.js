import React from 'react';
import CakeCard from '../CakeCard/CakeCard';
import './FeaturedCake.css'

function FeaturedCakes() {
  const cakes = [
    { id: 1, name: "Chocolate Truffle", image: "/images/chocolate-truffle.jpg" },
    { id: 2, name: "Red Velvet", image: "/images/Chocolate.png" },
    // Add more cakes here
  ];

  return (
    <section className="featured-cakes">
      <h2>Featured Cakes</h2>
      <div className="cake-list">
        {cakes.map(cake => <CakeCard key={cake.id} cake={cake} />)}
      </div>
    </section>
  );
}

export default FeaturedCakes;
