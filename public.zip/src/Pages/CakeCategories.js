import React, { useState } from 'react';
import CakeCard from '../Components/CakeCard/CakeCard';

function CakeCategories() {
  const [cakes, setCakes] = useState([
    { id: 1, category: "Chocolate Cakes", name: "Chocolate Truffle", image: "https://www.hotbreads.co.in/cdn/shop/products/0I4A6575_1200x1200.jpg?v=1641169677 "},
    { id: 2, category: "Fruit Cakes", name: "Mango Mousse", image: "/Images/Chocolate.png" },
    // Add more cakes here
  ]);

  return (
    <section className="cake-categories">
      <h2>Our Cake Categories</h2>
      <div className="cake-list">
        {cakes.map(cake => <CakeCard key={cake.id} cake={cake} />)}
      </div>
    </section>
  );
}

export default CakeCategories;
