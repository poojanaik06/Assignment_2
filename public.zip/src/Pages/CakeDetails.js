import React from 'react';
import { useParams } from 'react-router-dom';
import { useCart } from '../Components/Cartcontext/Cartcontext'; // Import the cart context

function CakeDetails() {
  const { cakeId } = useParams();
  const { addToCart } = useCart(); // Destructure addToCart function from context

  // Dummy cake data (In a real application, fetch this data based on cakeId)
  const cake = {
    id: cakeId,
    name: "Chocolate Truffle",
    description: "Delicious chocolate cake with rich truffle.",
    price: 20, // Keeping price as a number
  };

  // Function to handle adding item to cart
  const handleAddToCart = () => {
    addToCart(cake);
  };

  return (
    <section className="cake-details">
      <h2>{cake.name}</h2>
      <p>{cake.description}</p>
      <p>Price: ${cake.price}</p>
      <button onClick={handleAddToCart}>Add to Cart</button>
    </section>
  );
}

export default CakeDetails;
