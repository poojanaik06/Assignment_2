import React from 'react';
import ContactForm from '../Components/ContactForm/ContactForm';

function AboutUs() {
  return (
    <section className="about-us">
      <h2>About Happy Belly Bakes</h2>
      <p>Our bakery was founded in... [Bakery's Story]</p>
      <ContactForm />
    </section>
  );
}

export default AboutUs;
