import React from 'react';
import Banner from '../Components/Banner/Banner';
import FeaturedCakes from '../Components/FeaturedCakes/FeaturedCake';

function Home() {
  return (
    <div>
      <Banner />
      <section className="welcome">
        <h2>Welcome to Cake Delight!</h2>
        <p>Discover our delicious cakes crafted with love and the finest ingredients.</p>
      </section>
      <FeaturedCakes />
    </div>
  );
}

export default Home;
